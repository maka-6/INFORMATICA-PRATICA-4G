import javax.swing.*;
import java.awt.*;

public class GraphicPanel extends JPanel {
    private DisplayGrafico display;

    public GraphicPanel(DisplayGrafico display) {
        this.display = display;
        setPreferredSize(new Dimension(600, 400)); // oppure adatta alle tue misure
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (display != null && display.getImage() != null) {
            g.drawImage(display.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);
        }
    }

}